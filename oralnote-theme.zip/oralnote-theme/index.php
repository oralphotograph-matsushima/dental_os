<?php
// Fallback index. Please use the specific Page Templates like page-oralnote.php
get_header();
if ( have_posts() ) :
    while ( have_posts() ) : the_post();
        the_content();
    endwhile;
endif;
get_footer();
?>
